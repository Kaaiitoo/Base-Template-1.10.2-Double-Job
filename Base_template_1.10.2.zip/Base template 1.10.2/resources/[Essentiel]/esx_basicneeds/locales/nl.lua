Locales['nl'] = {
    ['used_eat'] = 'je hebt een %s gegeten',
    ['used_drink'] = 'je hebt een %s gedronken',
  }
