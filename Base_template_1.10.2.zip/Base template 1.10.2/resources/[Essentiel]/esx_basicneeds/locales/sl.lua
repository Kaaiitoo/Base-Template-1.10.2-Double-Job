Locales['sl'] = {
  ['used_food'] = 'Vi ste pojedli 1x %s',
  ['used_drink'] = 'Vi ste popili 1x %s',
  ['got_healed'] = 'Vi ste bili Pozdravljeni.'
}
