Locales['sr'] = {
  ['used_food'] = 'Pojeli ste 1x %s',
  ['used_drink'] = 'Popili ste 1x %s',
  ['got_healed'] = 'Vi ste izlečeni.'
}
