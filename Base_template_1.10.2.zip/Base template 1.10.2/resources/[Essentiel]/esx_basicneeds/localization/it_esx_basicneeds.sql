INSERT INTO `items` (`name`, `label`, `weight`) VALUES
    ('bread', 'Pane', 1),
    ('water', 'Acqua', 1)
;
