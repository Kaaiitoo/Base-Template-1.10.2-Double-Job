INSERT INTO `items` (`name`, `label`, `weight`) VALUES
	('bread', 'Hleb', 1),
	('water', 'Voda', 1)
;
