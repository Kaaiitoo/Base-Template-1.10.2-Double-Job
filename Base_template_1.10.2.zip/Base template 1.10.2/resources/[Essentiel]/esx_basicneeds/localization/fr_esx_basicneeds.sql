INSERT INTO `items` (`name`, `label`, `weight`) VALUES
	('bread', 'Pain', 1),
	('water', 'Eau', 1)
;
