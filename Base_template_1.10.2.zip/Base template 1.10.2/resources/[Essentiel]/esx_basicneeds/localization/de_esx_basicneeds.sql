INSERT INTO `items` (`name`, `label`, `weight`) VALUES
    ('bread', 'Brot', 1),
    ('water', 'Wasser', 1)
;
