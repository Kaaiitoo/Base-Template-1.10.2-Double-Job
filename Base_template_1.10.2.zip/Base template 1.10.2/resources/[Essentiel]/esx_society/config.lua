Config = {}

Config.Locale = GetConvar('esx:locale', 'fr')
Config.EnableESXIdentity = true
Config.MaxSalary = 3500
