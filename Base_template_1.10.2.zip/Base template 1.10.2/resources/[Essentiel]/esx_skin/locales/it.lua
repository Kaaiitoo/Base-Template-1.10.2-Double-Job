Locales["it"] = {
  ["skin_menu"] = "Menu Skin",
  ["use_rotate_view"] = "usa ~INPUT_FRONTEND_LS~ e ~INPUT_CHARACTER_WHEEL~ per ruotare la visuale.",
  ["skin"] = "cambia skin",
  ["saveskin"] = "salvare la skin",
}
