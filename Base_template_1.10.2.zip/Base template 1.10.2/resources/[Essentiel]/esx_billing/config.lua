Config = {}
Config.Locale = GetConvar('esx:locale', 'fr')
