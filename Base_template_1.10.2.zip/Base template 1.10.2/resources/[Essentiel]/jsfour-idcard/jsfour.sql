INSERT INTO `items` (`name`, `label`, `limit`, `rare`, `can_remove`) VALUES
('carteidentite', 'Carte Identité', 10, 0, 1),
('drive', 'Permis de conduire', 10, 0, 1), 
('ppa', 'PPA', 10, 0, 1);
