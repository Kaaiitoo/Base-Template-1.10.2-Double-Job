return {
	{
		items = {

		},
		points = {
		},
		zones = {
		
		},
		blip = {},
	},
}
