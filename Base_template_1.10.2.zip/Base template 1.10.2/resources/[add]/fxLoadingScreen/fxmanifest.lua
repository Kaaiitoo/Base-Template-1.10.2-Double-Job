



fx_version 'cerulean'

game 'gta5'

files {
  'web/**',
  'web/*'
}

loadscreen {
  'web/ui.html'
}

loadscreen_cursor 'yes'
loadscreen_manual_shutdown 'yes'
