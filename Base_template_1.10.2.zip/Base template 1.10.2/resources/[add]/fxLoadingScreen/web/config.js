Config = {};

Config.DiscordLink =  "https://discord.gg/agartha"

Config.InstagramLink = ""