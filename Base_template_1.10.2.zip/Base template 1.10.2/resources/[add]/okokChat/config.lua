Config = {}

Config.DateFormat = '%H:%M'

Config.StaffGroups = {
	'responsable',
	'admin',
	'kaito',
	'modo'
}

Config.AllowPlayersToClearTheirChat = false

Config.ClearChatCommand = 'clear'

Config.EnableStaffCommand = true

Config.StaffCommand = 'cs'

Config.AllowStaffsToClearEveryonesChat = false

Config.ClearEveryonesChatCommand = 'clearall'

Config.EnableStaffOnlyCommand = true

Config.StaffOnlyCommand = 'staffo'

